﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CelluarAutomate
{
    public partial class Form1 : Form
    {
        private const int CellSize = 15;
        private const int NumRows = 30;
        private const int NumCols = 30;

        private bool[,] cells;

        public Form1()
        {
            InitializeComponent();
            cells = new bool[NumRows, NumCols];
            InitializeCells();
        }

        private void InitializeCells()
        {
            Random random = new Random();
            for (int i = 0; i < NumRows; i++) // Заполнение массива клеток (1 или 0)
            {
                for (int j= 0; j < NumCols; j++)
                {
                    cells[i, j] = random.Next(2) == 0;
                }
                
            }
        }


        // Рисуем клеточки
        private void DrawCells()
        {
            Graphics g = panel1.CreateGraphics();
            g.Clear(Color.White);

            for (int i = 0; i < NumRows; i++)
            {
                for (int j = 0; j < NumCols; j++)
                {
                    Brush brush = cells[i, j] ? Brushes.Black : Brushes.White;
                    g.FillRectangle(brush, j * CellSize, i* CellSize, CellSize, CellSize);
                }
                
            }
        }

        // Построение массива клеток в соответсвии с правилами
        private void EvolveCells()
        {
            bool[,] newCells = new bool[NumRows, NumCols];

            for (int i = 0; i < NumRows; i++)
            {
                for (int j = 0; j < NumCols; j++)
                {
                    int neighbors = CountNeighbors(i, j);
                    newCells[i, j] = ApplyRule(cells[i, j], neighbors);
                }
            }

            cells = newCells;
        }

        // Считаем соседей 
        private int CountNeighbors(int row, int col)
        {
            int count = 0;

            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    if (i == 0 && j == 0)
                        continue;

                    int newRow = (row + i + NumRows) % NumRows;
                    int newCol = (col + j + NumCols) % NumCols;

                    if (cells[newRow, newCol]) count++;

                }
            }
            return count;
        }

        // Принимаем правила игры
        private bool ApplyRule(bool currentState, int neighbors)
        {

            if (currentState) 
                return neighbors == 2 || neighbors == 3;
            else 
                return neighbors == 3;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            EvolveCells();
            DrawCells();
        }

        private void BtnStart_Click_1(object sender, EventArgs e)
        {
            timer2.Start();
        }

        private void BtnStop_Click_1(object sender, EventArgs e)
        {
            timer2.Stop();
        }

        private void BtnRandomize_Click(object sender, EventArgs e) // Начиняем канвас рандомными клетками
        {
            InitializeCells();
            DrawCells();
        }
    }
}
